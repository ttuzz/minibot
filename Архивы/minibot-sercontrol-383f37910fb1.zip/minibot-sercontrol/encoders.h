/**
 * @file encoders.h
 * @brief MiniBot encoders
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "encoders.h" @endcode
 */

#ifndef ENCODERS_H_
#define ENCODERS_H_

#include "common.h"

extern int32_t left_enc, right_enc;

static inline void encoders_init()
    {
    left_enc = 0;
    right_enc = 0;
    }

#endif /* ENCODERS_H_ */
