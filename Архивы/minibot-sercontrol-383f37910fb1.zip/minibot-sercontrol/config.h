/**
 * @file config.h
 * @brief Config
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "config.h" @endcode
 */

#ifndef CONFIG_H_
#define CONFIG_H_

// Defined in project for Debug build
//#define DEBUG

// MiniBot with ATMega644
//#define MB_M644

/// Device id (stored in eeprom)
#define DEVICE_ID       0x0001

/// I2C Tx/Rx buffer size
#define I2C_MAX_BYTES   64
/// Command string buffer size
#define INPUT_MAX_BUF   I2C_MAX_BYTES * 2 + 5 + 2
/// Motor queue size
#define MOT_MAX_QSIZE   20

/// Encoders PID cfg
#define I_MAX 255
#define I_MIN -255
#define I_GAIN 0.01
#define P_GAIN 45
#define D_GAIN 50
/// Speed * VP = Distance 1/56 sec
#define VP     0.008

/// Soft RESET -> QFF0050A055AA
#define QRESET      0x50
#define QRES_CMP1   0xA0
#define QRES_CMP2   0x55
#define QRES_CMP3   0xAA

/// QFF0010{xx} & QFF0012{xx} (xx == 0x01 or 0x02) set motor direction
#define QMOT_LDIR   0x10
#define QMOT_RDIR   0x12

/// QFF0011{xx} & QFF0013{xx} set motor pwm
#define QMOT_LPWM   0x11
#define QMOT_RPWM   0x13

/// QFF0014[{tt}{ls}{rs}{lf}{rf}] queue table position
#define QMOT_QUEUE  0x14
#define QMQ_TIME    1
#define QMQ_LSTART  2
#define QMQ_RSTART  3
#define QMQ_LFIN    4
#define QMQ_RFIN    5

/// QFF08F0 - encoders state
/// Response {L0L1L2L3}{R0R1R2R3} int32_t in little-endian
#define QENCODERS   0xF0

/// QFF01F1 - line sensor
/// Response {xx} uint8_t
#define QLINE       0xF1

// TODO
#define QBUMP       0xF2

// TODO
#define QRC5        0xF3

/// QFF04FF - version
#define QVERSION    0xFF

#endif /* CONFIG_H_ */
