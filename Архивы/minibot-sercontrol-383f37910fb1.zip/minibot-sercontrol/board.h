/**
 * @file board.h
 * @brief MiniBot pinout defines
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "board.h" @endcode
 */

#ifndef BOARD_H_
#define BOARD_H_

#include <avr/io.h>
#include <stdint.h>

/// Color led ddr
#define MB_LED_CL_DDR   DDRC
/// Color led in
#define MB_LED_CL_IN    PINC
/// Color led out
#define MB_LED_CL_OUT   PORTC

/// Color led 1 Red Pin (Right)
#define MB_LED_CL_RP1   PC4
/// Color led 1 Green Pin (Right)
#define MB_LED_CL_GP1   PC5
/// Color led 2 Red Pin (Left)
#define MB_LED_CL_RP2   PC6
/// Color led 2 Green Pin (Left)
#define MB_LED_CL_GP2   PC7

/// Color led ddr init
static inline void mb_led_cl_init() __attribute__((naked));
static inline void mb_led_cl_init()
    {
    MB_LED_CL_DDR |= (1 << MB_LED_CL_RP1) | (1 << MB_LED_CL_GP1) | (1
            << MB_LED_CL_RP2) | (1 << MB_LED_CL_GP2);
    }

/// IR Detector led ddr
#define MB_LED_IRD_DDR  DDRB
/// IR Detector led in
#define MB_LED_IRD_IN   PINB
/// IR Detector led out
#define MB_LED_IRD_OUT  PORTB

/// IR Detector led Front Left Pin
#define MB_LED_IRD_FLP  PB3
/// IR Detector led Front Right Pin
#define MB_LED_IRD_FRP  PB1
/// IR Detector led Back Pin
#define MB_LED_IRD_BP   PB0

/// IR Detector led ddr init
static inline void mb_led_ird_init() __attribute__((naked));
static inline void mb_led_ird_init()
    {
    MB_LED_IRD_DDR |= (1<<MB_LED_IRD_FLP)|(1<<MB_LED_IRD_FRP)|(1<<MB_LED_IRD_BP);
    }

/// IR Line & Encoder led ddr
#define MB_LED_IRLE_DDR DDRD
/// IR Line & Encoder led in
#define MB_LED_IRLE_IN  PIND
/// IR Line & Encoder led out
#define MB_LED_IRLE_OUT PORTD

/// IR Line & Encoder led pin
#define MB_LED_IRLE_PIN PD6

/// IR Line & Encoder led ddr init
static inline void mb_led_irle_init() __attribute__((naked));
static inline void mb_led_irle_init()
    {
    MB_LED_IRLE_DDR |= (1 << MB_LED_IRLE_PIN);
    }

/// Photo Sensors ddr
#define MB_PS_LE_DDR    DDRA
/// Photo Sensors in
#define MB_PS_LE_IN     PINA
/// Photo Sensors out
#define MB_PS_LE_OUT    PORTA

/// Encoder sensor Rigth Pin
#define MB_PS_ENC_RP    PA1
/// Encoder sensor Left Pin
#define MB_PS_ENC_LP    PA2

/// Line sensor Left Pin
#define MB_PS_LINE_LP   PA4
/// Line sensor Center Pin
#define MB_PS_LINE_CP   PA3
/// Line sensor Right Pin
#define MB_PS_LINE_RP   PA0

/// Photo Sensors ddr init
static inline void mb_ps_le_init() __attribute__((naked));
static inline void mb_ps_le_init()
    {
    MB_PS_LE_DDR &= ~((1 << MB_PS_ENC_RP) | (1 << MB_PS_ENC_LP) | (1
            << MB_PS_LINE_LP) | (1 << MB_PS_LINE_CP) | (1 << MB_PS_LINE_RP));
    }

/// TSOP Front Left Pin TODO!
#define MB_PS_TSOP_FLP
/// TSOP Front Right Pin TODO!
#define MB_PS_TSOP_FRP
/// TSOP Back Pin TODO!
#define MB_PS_TSOP_BP

/// Motor Direction ddr
#define MB_MOT_DIR_DDR  DDRC
/// Motor Direction in
#define MB_MOT_DIR_IN   PINC
/// Motor Direction out
#define MB_MOT_DIR_OUT  PORTC

/// Motor Direction Left Pin
#define MB_MOT_DIR_LP   PC3
/// Motor Direction Right Pin
#define MB_MOT_DIR_RP   PC2

/// Motor Direction ddr init
static inline void mb_mot_dir_init() __attribute__((naked));
static inline void mb_mot_dir_init()
    {
    MB_MOT_DIR_DDR |= (1<<MB_MOT_DIR_LP)|(1<<MB_MOT_DIR_RP);
    }

/// Motor PWM ddr
#define MB_MOT_PWM_DDR  DDRD
/// Motor PWM in
#define MB_MOT_PWM_IN   PIND
/// Motor PWM out
#define MB_MOT_PWM_OUT  PORTD

/// Motor PWM Left Pin
#define MB_MOT_PWM_LP   PD5
/// Motor PWM Right Pin
#define MB_MOT_PWM_RP   PD4

/// Motor Direction ddr init
static inline void mb_mot_pwm_init() __attribute__((naked));
static inline void mb_mot_pwm_init()
    {
    MB_MOT_PWM_DDR |= (1<<MB_MOT_PWM_LP)|(1<<MB_MOT_PWM_RP);
    }

/// PWM timer Left Register
#define MB_MOT_PWM_LR   OCR1A
/// PWM timer Right Register
#define MB_MOT_PWM_RR   OCR1B

/// Speacker ddr
#define MB_SPK_DDR  DDRD
/// Speaker in
#define MB_SPK_IN   PIND
/// Speaker out
#define MB_SPK_OUT  PORTD

/// Speaker pin
#define MB_SPK_PIN  PD7

/// Speaker ddr init
static inline void mb_spk_init() __attribute__((naked));
static inline void mb_spk_init()
    {
    MB_SPK_DDR |= (1 << MB_SPK_PIN);
    }

/**
 * Init All
 */
static inline void mb_init()
    {
    mb_led_cl_init();
    mb_led_irle_init();
    mb_spk_init();
    mb_ps_le_init();
    mb_mot_dir_init();
    mb_mot_pwm_init();
    }

#endif /*PINOUT_H_*/
