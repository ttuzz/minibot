/**
 * @file encoders.c
 * @brief MiniBot encoders
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

#include "encoders.h"

int32_t left_enc = 0, right_enc = 0;
