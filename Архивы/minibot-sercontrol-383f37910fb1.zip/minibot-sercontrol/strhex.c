/**
 * @file strhex.c
 * @brief Dec 2 Hex 2 Dec
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

#include <ctype.h>

#include "common.h"

void dec2hex(char dec, char *hi, char *lo)
    {
    char c1 = (dec & 0xf0) >> 4;
    char c2 = (dec & 0x0f);
    *hi = (c1 > 9) ? c1 + 'A' - 10 : c1 + '0';
    *lo = (c2 > 9) ? c2 + 'A' - 10 : c2 + '0';
    }

bool hex2dec(char hi, char lo, uint8_t* dec)
    {
    if ( (hi < '0' || hi > 'F' || (hi > '9' && hi < 'A')) || (lo < '0' || lo
            > 'F' || (lo > '9' && lo < 'A')) )
        return false;

    *dec = ((hi > '9') ? (hi - 'A' + 10) : (hi - '0')) * 16 + ((lo > '9') ? (lo
            - 'A' + 10) : (lo - '0'));
    return true;
    }
