/**
 * @file requests.h
 * @brief Request processing functions
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "requests.h" @endcode
 */

#ifndef REQESTS_H_
#define REQESTS_H_

/// MiniBot includes
#include "common.h"

/// Motor queue
struct mot_queue_s
    {
        int8_t l_start; ///< left start speed
        int8_t l_fin;   ///< left fin speed
        int8_t r_start; ///< right start speed
        int8_t r_fin;   ///< right fin speed
        int16_t time;   ///< command time
    };

/// Motor commands queue
extern struct mot_queue_s mot_queue[MOT_MAX_QSIZE];
/// Motor commands queue counter
extern uint8_t mot_qsize;
/// Motor timer
extern int16_t mot_qtimer;

/**
 * Process command decoding
 */
bool command_decode(char *str, int len);

/*
 * Local command request
 */
//static inline bool local_request(int address, uint8_t* request, int req_len,
//        uint8_t* answer, int ans_len);

/*
 * I2C command request
 */
//static inline bool i2c_request(int address, uint8_t* request, int req_len,
//        uint8_t* answer, int ans_len);

#endif /* REQESTS_H_ */
