/**
 * @file timers.c
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 *
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

/// MiniBot includes
#include "timers.h"

struct pid_s left_pid;
struct pid_s right_pid;

#ifndef MB_M644
/**
 * Encoder
 */
ISR(TIMER2_OVF_vect)
    {
    // reload TCNT
    TCNT2 = 0x80;

    static uint8_t l_last, r_last;
    uint8_t l_curr, r_curr;

    l_curr = (MB_PS_LE_IN & (1 << MB_PS_ENC_LP));
    r_curr = (MB_PS_LE_IN & (1 << MB_PS_ENC_RP));

    if ( l_curr != l_last )
        {
        l_last = l_curr;
        if ( MB_MOT_DIR_IN & (1 << MB_MOT_DIR_LP) )
            left_enc++;
        else
            left_enc--;
        }

    if ( r_curr != r_last )
        {
        r_last = r_curr;
        if ( MB_MOT_DIR_IN & (1 << MB_MOT_DIR_RP) )
            right_enc++;
        else
            right_enc--;
        }
    }
#endif // MB_M644

/**
 * Main motor control irq
 */
ISR(TIMER0_OVF_vect)
    {
    //TCNT0 = 0x00;

    // Need next command?
    if ( mot_qsize > 0 && (mot_qtimer == mot_queue[0].time) )
        {
        mot_qsize--;
        mot_qtimer = 0;
        for ( uint8_t i = 0 ; i < mot_qsize ; i++ )
            {
            mot_queue[i] = mot_queue[i + 1];
            }
        if ( !mot_qsize )
            {
            MB_MOT_PWM_LR = 0x0000;
            MB_MOT_PWM_RR = 0x0000;
            } // if ( mot_qsize > 0 )
        }

    // Commands exist?
    if ( mot_qsize > 0 )
        {

        static double l_a, l_v, l_vp=0;
        static double r_a, r_v, r_vp=0;
        int16_t l, r;

        l_a = (mot_queue[0].l_fin - mot_queue[0].l_start) / mot_queue[0].time;
        l_v = l_a * mot_qtimer + mot_queue[0].l_start;
        l_vp += l_v * VP;

        r_a = (mot_queue[0].r_fin - mot_queue[0].r_start) / mot_queue[0].time;
        r_v = r_a * mot_qtimer + mot_queue[0].r_start;
        r_vp += r_v * VP;

        l = (int16_t) update_pid(&left_pid, (l_vp - left_enc), left_enc);
        r = (int16_t) update_pid(&right_pid, (r_vp - right_enc), right_enc);

        mot_qtimer++;

#ifdef DEBUG
# if 1
        printf("#ti timer: %d, l_a: %G, l_v: %G, l_vp: %G, l_enc: %ld, l_pid: %d\n",
                mot_qtimer, l_a, l_v, l_vp, left_enc, l);
        printf("#ti timer: %d, r_a: %G, r_v: %G, r_vp: %G, r_enc: %ld, r_pid: %d\n",
                mot_qtimer, r_a, r_v, r_vp, right_enc, r);
# else
        printf("#ti l: %ld (%ld) lpwm: %d r: %ld (%ld) rpwm: %d\n",
                (int32_t) l_vp, left_enc, l, (int32_t) r_vp, right_enc, r);
# endif
#endif

        if ( l > 0 )
            // LeftDrive - Forward
            MB_MOT_DIR_OUT |= (1 << MB_MOT_DIR_LP);
        else
            // LeftDrive - Backward
            MB_MOT_DIR_OUT &= ~(1 << MB_MOT_DIR_LP);
        MB_MOT_PWM_LR = ( abs(l) > 255 ) ? 0xFF : abs(l);

        if ( r > 0 )
            // RightDrive - Forward
            MB_MOT_DIR_OUT |= (1 << MB_MOT_DIR_RP);
        else
            // RightDrive - Backward
            MB_MOT_DIR_OUT &= ~(1 << MB_MOT_DIR_RP);
        MB_MOT_PWM_RR = ( abs(r) > 255 ) ? 0xFF : abs(r);
        }
    }
