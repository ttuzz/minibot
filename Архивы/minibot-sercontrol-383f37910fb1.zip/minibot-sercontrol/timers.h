/**
 * @file timers.h
 * @brief Timers ISR
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 *
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "timers.h" @endcode
 */

#ifndef TIMERS_H_
#define TIMERS_H_

/// MiniBot includes
#include "common.h"

extern struct pid_s left_pid;  /* = { .d_state=0, .i_state=0, .i_max=I_MAX, .i_min=I_MIN, .i_gain=I_GAIN, .p_gain=P_GAIN, .d_gain=D_GAIN } */
extern struct pid_s right_pid; /* = { .d_state=0, .i_state=0, .i_max=I_MAX, .i_min=I_MIN, .i_gain=I_GAIN, .p_gain=P_GAIN, .d_gain=D_GAIN } */

/**
 * Timer/Counter-0
 * Mode: Normal (1), clk/1024, ~ 56 Hz (clk=14.7456e6 Hz)
 * Ovf interrupt enable
 */
static inline void timer0_init() __attribute__((naked));
static inline void timer0_init()
    {
    TCCR0 = (0 << WGM01) | (0 << WGM00) | (1 << CS02) | (0 << CS01) | (1
            << CS00);
    TCNT0 = 0x00;
    TIMSK |= (1 << TOIE0);
    }

/**
 * Timer/Counter-1
 * Mode: Fast PWM 8-bit (5), clk/8, ~ 7 kHz (clk=14.7456e6 Hz)
 * OC1A & OC1B non inverted pwm
 */
static inline void timer1_init() __attribute__((naked));
static inline void timer1_init()
    {
    TCNT1 = 0x0000;
    OCR1A = 0x0000;
    OCR1B = 0x0000;
    TCCR1A = (1 << COM1A1) | (0 << COM1A0) | (1 << COM1B1) | (0 << COM1B0)
        | (0 << WGM11) | (1 << WGM10);
    TCCR1B = (0 << WGM13) | (1 << WGM12) | (0 << CS12)
        | (1 << CS11) | (0 << CS10);
    }

#ifndef MB_M644

/**
 * Timer/Counter-1
 * Mode: Normal (1), clk/1, ~ 116 kHz (clk=14.7456e6 Hz)
 * Ovf interrupt enable
 */
static inline void timer2_init() __attribute__((naked));
static inline void timer2_init()
    {
    TCCR2 = (0 << WGM21) | (0 << WGM20) | (0 << CS22) | (1 << CS21) | (0
            << CS20);
    TCNT2 = 0x80;
    TIMSK |= (1 << TOIE2);
    }

#endif // MB_M644

/*
ISR(TIMER0_OVF_vect)
use mot_qsize, mot_qtimer, mot_queue from requests.h
*/

#endif /* TIMERS_H_ */
