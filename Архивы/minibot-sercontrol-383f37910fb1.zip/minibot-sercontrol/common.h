/**
 * @file common.h
 * @brief MiniBot Common func
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "common.h" @endcode
 */

#ifndef COMMON_H_
#define COMMON_H_

/// std
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

/// AVR includes
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

/// Util includes
#include <util/delay.h>

/// MiniBot includes
#include "config.h"
#include "pid.h"
#include "board.h"
#include "usart.h"
#include "requests.h"
#include "timers.h"
#include "encoders.h"

extern uint16_t device_id;

#define stdbeep()   beep(1500, 200)

/**
 * Base beep func.
 * @param tone _dalay_loop_2 arg
 * @param time count
 */
void beep(int tone, int time);

/**
 * Convert value (uint8_t) to hex chars
 */
void dec2hex(char dec, char *hi, char *lo);

/**
 * Convert hex chars to value (uint8_t)
 */
bool hex2dec(char hi, char lo, uint8_t* dec);

#endif /*COMMON_H_*/
