/**
 * @file main.c
 * @brief MiniBot Serial Controlled
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

#include <avr/eeprom.h>

/// MiniBot includes
#include "common.h"

// Device id no.
uint16_t device_id;

// EEPROM cfg's.
uint16_t EEMEM ee_device_id = DEVICE_ID;
struct pid_s EEMEM ee_init_pid = {
    .d_state = 0,
    .i_state = 0,
    .i_max   = I_MAX,
    .i_min   = I_MIN,
    .i_gain  = I_GAIN,
    .p_gain  = P_GAIN,
    .d_gain  = D_GAIN
    };

/// Main
int main()
    {
    char inbuf[INPUT_MAX_BUF];

    // HwInit
    mb_init();
    timer0_init();
    timer1_init();
#ifndef MB_M644
    timer2_init();
#endif // MB_M644

    // Turn on encoder led's
    MB_LED_IRLE_OUT |= (1<<MB_LED_IRLE_PIN);
    // Turn on green led
    MB_LED_CL_OUT |= (1<<MB_LED_CL_GP1);

    //usart_init(B9600);
    usart_init(B115200);
    // use USART device for stdio
    stderr = stdout = stdin = &usart_fdev;

    // load cfg's from eeprom
    device_id = eeprom_read_word(&ee_device_id);
    eeprom_read_block(&left_pid, &ee_init_pid, sizeof(left_pid));
    eeprom_read_block(&right_pid, &ee_init_pid, sizeof(right_pid));

    // enable interrupts
    sei();

    puts("Ready!");

#ifdef DEBUG
    printf("#pid P: %G, I: %G, D: %G\n", left_pid.p_gain, left_pid.i_gain, left_pid.d_gain);
#endif

    // ready beep :)
    stdbeep();

    while ( true )
        {
        if ( fgets(inbuf, INPUT_MAX_BUF, stdin) == NULL )
            {
            printf("fgets() error. buffer: %s", inbuf);
            break;
            }
        bool proc = command_decode(inbuf, strnlen(inbuf, INPUT_MAX_BUF) - 1);

        if ( !proc )
            {
            stdbeep();
            }

        } // while ( true )

    return 0;
    }
