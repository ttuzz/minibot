/**
 * @file pid.h
 * @brief MiniBot PID func
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 *
 * @code #include "pid.h" @endcode
 */

#ifndef PID_H_
#define PID_H_

/**
 * PID struct
 */
struct pid_s
    {
        double d_state; //!< Last position input
        double i_state; //!< Integrator state
        double i_max, i_min; //!< Maximum and minimum allowable integrator state
        double i_gain; //!< integral gain
        double p_gain; //!< proportional gain
        double d_gain; //!< derivative gain
    };

/**
 * PID main loop
 */
static inline double update_pid(struct pid_s * pid, double error,
        double position)
    {
    double p_term, d_term, i_term;

    p_term = pid->p_gain * error;

    // calculate the proportional term
    // calculate the integral state with appropriate limiting
    pid->i_state += error;
    if ( pid->i_state > pid->i_max )
        pid->i_state = pid->i_max;
    else if ( pid->i_state < pid->i_min )
        pid->i_state = pid->i_min;

    // calculate the integral term
    i_term = pid->i_gain * pid->i_state;
    d_term = pid->d_gain * (position - pid->d_state);
    pid->d_state = position;

    return p_term + i_term - d_term;
    }

#endif /* PID_H_ */
