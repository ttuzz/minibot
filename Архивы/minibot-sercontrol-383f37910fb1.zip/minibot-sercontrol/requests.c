/**
 * @file requests.c
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @author =DeaD=
 * @author Сергей (Segment) <virus179@narod.ru>
 *
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

#include <avr/wdt.h>
#include <util/atomic.h> // avr-libc >= 1.6.x
#include "common.h"

// Motor commands queue
struct mot_queue_s mot_queue[MOT_MAX_QSIZE];
// Motor commands queue counter
uint8_t mot_qsize = 0;
// Motor timer
int16_t mot_qtimer = 0;

/**
 * Local command request
 */
static inline bool local_request(int address, uint8_t* request, int req_len,
        uint8_t* answer, int ans_len)
    {

    // RESET?
    if ( request[0] == QRESET && req_len == 4 )
        {
        if ( (request[1] == QRES_CMP1)||(request[2] == QRES_CMP2)||(request[3] == QRES_CMP3) )
            {
            wdt_enable(WDTO_15MS);
            while ( true )
                { // wait reset on wdt
                };
            }
        else
            puts("X12ResetNCmp");

        return false;
        }
    else

    // Direct motor control, left direction?
    if ( request[0] == QMOT_LDIR && req_len == 2 )
        {
        if ( request[1] == 0x01 ) // set forward?
            {
            MB_MOT_DIR_OUT |= (1 << MB_MOT_DIR_LP);

            return true;
            }
        else if ( request[1] == 0x02 ) // set backward?
            {
            MB_MOT_DIR_OUT &= ~(1 << MB_MOT_DIR_LP);

            return true;
            }
        else
            {
            puts("X11MotDirIncor");
            return false;
            }
        }
    else

    // Direct motor control, left pwm?
    if ( request[0] == QMOT_LPWM && req_len == 2 )
        {
        MB_MOT_PWM_LR = request[1];

        return true;
        }
    else

    // Direct motor control, right direction?
    if ( request[0] == QMOT_RDIR && req_len == 2 )
        {
        if ( request[1] == 0x01 ) // set forward?
            {
            MB_MOT_DIR_OUT |= (1 << MB_MOT_DIR_RP);

            return true;
            }
        else if ( request[1] == 0x02 ) // set backward?
            {
            MB_MOT_DIR_OUT &= ~(1 << MB_MOT_DIR_RP);

            return true;
            }
        else
            {
            puts("X11MotDirIncor");
            return false;
            }
        }
    else

    // Direct motor control, right pwm?
    if ( request[0] == QMOT_RPWM && req_len == 2 )
        {
        MB_MOT_PWM_RR = request[1];

        return true;
        }
    else

    // Motor queue command, Flush Queue?
    if ( request[0] == QMOT_QUEUE && req_len == 1 )
        {
        ATOMIC_BLOCK(ATOMIC_FORCEON)
            {
            mot_qsize = 0;
            MB_MOT_PWM_LR = 0x0000;
            MB_MOT_PWM_RR = 0x0000;
            }

#ifdef DEBUG
        puts("#mq flush");
#endif

        return true;
        }
    else

    // Motor queue command, Add to Queue?
    if ( request[0] == QMOT_QUEUE && req_len > 1 )
        {
        // QFF0014({tt}{ls}{rs}{lf}{rf})+ => Add to Queue

        if ( mot_qsize == 0 )
            {
            mot_qtimer = 0;
            }

        for ( uint8_t rv = 0, iter = 0 ; rv + 4 < req_len ; rv += 5, iter++ )
            {
            if ( mot_qsize >= MOT_MAX_QSIZE )
                {
                // queue overflow error
                printf("X10MotQueueOvf %d\n", iter);
                return false;
                }

            ATOMIC_BLOCK(ATOMIC_FORCEON)
                {
                mot_queue[mot_qsize].time = request[QMQ_TIME + rv];
                mot_queue[mot_qsize].l_start = request[QMQ_LSTART + rv];
                mot_queue[mot_qsize].r_start = request[QMQ_RSTART + rv];
                mot_queue[mot_qsize].l_fin = request[QMQ_LFIN + rv];
                mot_queue[mot_qsize].r_fin = request[QMQ_RFIN + rv];
                mot_qsize++;
                }

#ifdef DEBUG
            printf("#mq time: %d ls: %d rs: %d lf: %d rf: %d\n",
                    mot_queue[mot_qsize - 1].time,
                    mot_queue[mot_qsize - 1].l_start,
                    mot_queue[mot_qsize - 1].r_start,
                    mot_queue[mot_qsize - 1].l_fin,
                    mot_queue[mot_qsize - 1].r_fin);
#endif

            }
        return true;
        }
    else

    /* Encoders status?
     * Response: {left}{right}
     *  left    - int32 - little endian left encoder status
     *  right   - int32 - little endian right encoder status
     */
    if ( request[0] == QENCODERS && req_len == 1 )
        {
        memcpy(answer, (uint8_t*) &left_enc, sizeof(left_enc));
        memcpy(answer + sizeof(left_enc), (uint8_t*) &right_enc,
                sizeof(right_enc));

#ifdef DEBUG
        printf("#es l: %ld, r: %ld\r", left_enc, right_enc);
#endif

        return true;
        }
    else

    /* Line sensors status?
     * Response: {sflag}
     *  sflag    - uint8 - bit-mask
     */
    if ( request[0] == QLINE && req_len == 1 )
        {
        answer[0] = MB_PS_LE_IN & ((1 << MB_PS_LINE_LP) | (1 << MB_PS_LINE_CP)
                | (1 << MB_PS_LINE_RP));
        return true;
        }
    else

    /* Version & Device ID info?
     * Response: {'M'}{mj}{mi}{rv}{dvid}
     *      mj      - uint8     - major
     *      mi      - uint8     - minor
     *      rv      - uint8     - revision
     *      dvid    - uint16    - little endian device id
     */
    if ( request[0] == QVERSION && req_len == 1 )
        {
        uint8_t i = 0;
        // 'M' 0.1.0 - motor queue only
        // 'M' 0.2.0 - motor queue + direct motor control
        // 'M' 0.3.0 - + encoders & PID
        // 'M' 0.3.6 - + I2C

        answer[i++] = 'M';
        answer[i++] = 0;
        answer[i++] = 3;
        answer[i++] = 1;
        memcpy(&answer[i++], &device_id, sizeof(device_id));

        return true;
        }

    return false;
    }

/**
 * I2C command request
 * TODO
 */
static inline bool i2c_request(int address, uint8_t* request, int req_len,
        uint8_t* answer, int ans_len)
    {
    return false;
    }

/*
 * Process command decoding
 */
bool command_decode(char *str, int len)
    {
    uint8_t current = 5;
    // address Q{xx}xx
    uint8_t address = 0;
    // read cout Qxx{xx}
    uint8_t read_bytes = 0;
    // send cout Qxxxx[{xx}]*
    uint8_t send_bytes = 0;
    // buffers
    uint8_t buf_send[I2C_MAX_BYTES];
    uint8_t buf_read[I2C_MAX_BYTES];
    // request proc state (false==error, true==normal)
    bool res;

    if ( str[0] != 'Q' )
        {
        puts("X01CmdStart");
        return false;
        }
    if ( len < 5 )
        {
        puts("X02CmdLen");
        return false;
        }
    if ( !hex2dec(str[1], str[2], &address) )
        {
        puts("X03Adr");
        return false;
        }
    if ( !hex2dec(str[3], str[4], &read_bytes) )
        {
        puts("X04ReadCout");
        return false;
        }
    if ( read_bytes > I2C_MAX_BYTES )
        {
        puts("X05ReadCoutOvf");
        return false;
        }
    if ( ((len - current) & 0x01) == 1 )
        {
        puts("X06SendCout");
        return false;
        }

    while ( current < len )
        {
        if ( !hex2dec(str[current], str[current + 1], &(buf_send[send_bytes])) )
            {
            puts("X07SendHex");
            return false;
            };
        current += 2;
        send_bytes++;
        // can't be true
        //        if ( send_bytes > I2C_MAX_BYTES )
        //            {
        //            puts("X08SendCoutOvf");
        //            return false;
        //            };
        }

    // Processing i2c request
#ifdef DEBUG
    printf("#c addr: 0x%02X r: %d w: %d\n", address, read_bytes, send_bytes);
#endif

    // Test buf_read[] clearing
    memset(buf_read, 0x00, read_bytes);

    if ( address == 0xFF )
        {
        res
                = local_request(address, buf_send, send_bytes, buf_read,
                        read_bytes);
        }
    else // address < 0x7F
        {
        res = i2c_request(address, buf_send, send_bytes, buf_read, read_bytes);
        }

    if ( res == false )
        {
        puts("X09ReqProc");
        return false;
        }

    //Forming answer from i2c for RS-232
    putchar('R');
    for ( int i = 0 ; i < read_bytes ; i++ )
        {
        char hi, lo;

        dec2hex(buf_read[i], &hi, &lo);
        putchar(hi);
        putchar(lo);
        };
    putchar('\n');

    return true;
    }
