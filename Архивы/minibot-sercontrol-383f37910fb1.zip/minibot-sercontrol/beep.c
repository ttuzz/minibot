/**
 * @file beep.c
 * @brief MiniBot Beep()
 * @author Vladimir Ermakov <vooon341@gmail.com>
 * @license LGPL <http://www.gnu.org/licenses/lgpl.html>
 */

#include <util/delay.h>

#include "common.h"

void beep(int tone, int time)
    {
    for ( int i = 0; i < time ; i++ )
        {
        _delay_loop_2(tone);
        MB_SPK_OUT ^= (1 << MB_SPK_PIN);
        }
    MB_SPK_OUT &= ~(1 << MB_SPK_PIN);
    }
