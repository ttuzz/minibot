#include "io2313.h"
#include "ina90.h"
                                 
//#define   N   104    // 9600@1Mhz
//#define   N   62    // 19200@1Mhz
#define   N   26    // 38400@1Mhz
#define   C   1     
#define   R   1

#define   RDR   0                              
#define   TD    6                             
#define   BUSY  7


void uart_init(void);
void uart_transmit(char data);

struct{
  char u_buffer;                                                      
  char u_status;
  char u_reload;
  char u_bit_cnt;
  }glob;


//**************************************************************************
//*
//* EXT_INT0 - External Interrupt Routine 0
//*
//*
//* DESCRIPTION
//* This routine is executed when a negative edge on the incoming serial
//* signal is detected. It disables further external interrupts and enables
//* timer interrupts (bit-timer) because the UART must now receive the
//* incoming data. 

void interrupt [INT0_vect] ext_int0(void)
{
  glob.u_status = (1<<BUSY);
  TCNT0 = (256-(N+N/2)+(29/C));
  TIFR = (1<<TOIE0);
  TIMSK = (1<<TOIE0);
  glob.u_bit_cnt = 0;
  GIMSK = 0;
  glob.u_reload = (256-N+(8/C));
}

//**************************************************************************
//*
//* TIM0_OVF - Timer/Counter 0 Overflow Interrupt
//*
//*
//* DESCRIPTION
//* This routine coordinates the transmition and reception of bits. This 
//* routine is automatically executed at a rate equal to the baud-rate. When
//* transmitting, this routine shifts the bits and sends it. When receiving,
//* it samples the bit and shifts it into the buffer.
//*
//* The serial routines uses a status register (u_status): READ-ONLY.
//*    BUSY  This bit indicates whenever the UART is busy
//*    TD  Transmit Data. Set when the UART is transmitting
//*    RDR  Receive Data Ready. Set when new data has arrived
//*      and it is ready for reading.
//*
//* When the RDR flag is set, the (new) data can be read from u_buffer.
//*
//* This routine also sets bits in TIMSK and TIMSK. See ext_int0 description

void interrupt [TIMER0_OVF0_vect] tim0_ovf(void)
{
  TCNT0 = glob.u_reload;
  glob.u_bit_cnt++;
  if(!(glob.u_status&TD))    // Transmit secton
  {
    if(glob.u_bit_cnt<=7)
    {             
      if(glob.u_buffer&0x01)
      {
        PORTD|=(1<<PD4);
      }
      else
      { 
        PORTD &=(~(1<<PD4));    
      }
      glob.u_buffer =glob.u_buffer>>1;
    }
    PORTD|=(1<<PD4);   
    if(!(glob.u_bit_cnt == 8))
    {
      GIMSK = (1<<INT0);
      TIMSK = 0;
      glob.u_status = ~((1<<BUSY)|(1<<TD));
    }
  }
  else                // Receive routine
  {              
    if(!(glob.u_bit_cnt== 9))
    {
      glob.u_buffer = (glob.u_buffer>>1);
      if(PIND&(1<<PD2))
      { 
        glob.u_buffer |=0x80;            
      }
    }                          
    else
    {
      glob.u_status = (~(1<<RDR));
    } 
  }
}

//**************************************************************************
//* uart_init - Subroutine for UART initialization
//*
//* DESCRIPTION
//* This routine initializes the UART. It sets the timer and enables the
//* external interrupt (receiving). To enable the UART the global interrupt
//* flag must be set (with SEI).

void uart_init(void)
{
  TCCR0 = 1;              // ?
  MCUCR = (1<<ISC01);                                 
  GIFR = (1<<INTF0);      // Interrupt on falling edge
  GIMSK = (1<<INT0);      // Interrupt on falling edge  
}                         
            
//**************************************************************************
//* uart_transmit - Subroutine for UART transmittal
//*
//* DESCRIPTION
//* This routine initialize the UART to transmit data. The data to be sent
//* must be located in u_transmit. 
//*
             
void uart_transmit(char data)
{               
  glob.u_status = (1<<BUSY)|(1<<TD);
  GIMSK = 0;                    // Disable external interrupt
  glob.u_bit_cnt = 0xFF;            
  glob.u_buffer = data;   
  TIFR = (1<<TOIE0);          
  TIMSK = (1<<TOIE0);           // Enable timer interrupt
  glob.u_reload = (256-N+(8/C));     // Set reload value
  TCNT0 = (256-N+(14/C));       //Set 1st timer reload value
  PORTD = (1<<PD4);             //Clear PD4
}                                                            

 
void main(void)
{
       
  char ee_adr;       
  char loc_buffer;
  
  DDRB = 0xFF;  
  PORTD = 0xFF;
  PORTB = 0xFF;
  DDRD = (1<<DDD4);
 
 PORTD = PORTD^PD4;
 if (PIND & 0x10) PORTD=0x10; else PORTD=0x10;
 
  uart_init();
  _SEI();                                                     
  
  do
  {
    do
    {
    } while(!(glob.u_status&(1<<RDR)));
    loc_buffer = glob.u_buffer; 
    PORTB = loc_buffer;
    ee_adr = 0;
    do
    {
      _EEGET(glob.u_buffer,ee_adr++);
      uart_transmit(glob.u_buffer);
      do
      {
      }while(glob.u_status&(1<<TD));
      if(ee_adr==10)
      {
        uart_transmit(loc_buffer);
        do
        {
        } while(glob.u_status&(1<<TD));
      } 
    }while(ee_adr<13);
  }while(1);
}      
  
  
    
